//
//  MemoryLeakView.swift
//  AWiFi
//
//  Created by 成杰 on 16/5/23.
//  Copyright © 2016年 A. All rights reserved.
//

import UIKit

class MemoryLeakView: UIView {

    var buttonAction: (() -> ())?
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        commonInit()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        commonInit()
    }
    
    private func commonInit() {
        
        backgroundColor = UIColor.whiteColor()
        
        addButton()
    }
    
    // MARK: - UI's Action
    
    private func addButton() {
        
        let buttonW = CGFloat(80)
        let buttonH = CGFloat(50)
        let buttonX = bounds.width/2 - buttonW/2
        let buttonY = bounds.height/2 - buttonH/2
        let buttonF = CGRect(x: buttonX,
                             y: buttonY,
                             width: buttonW,
                             height: buttonH)
        let button = UIButton(frame: buttonF)
        button.backgroundColor = .blackColor()
        button.setTitle("点我", forState: .Normal)
        button.addTarget(self,
                         action: #selector(buttonClicked),
                         forControlEvents: .TouchUpInside)
        self.addSubview(button)
    }
    
    private dynamic func buttonClicked() {
        
    //removeFromSuperview()
        
        if buttonAction != nil {
            buttonAction!()
        }
    }
    
    deinit {
        print(self.dynamicType, #function)
    }
}
