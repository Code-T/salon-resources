//
//  ViewController.swift
//  Memory
//
//  Created by 成杰 on 16/6/22.
//  Copyright © 2016年 swiftc.org. All rights reserved.
//

import UIKit

class Person {
    
    let name: String
    lazy var printName: ()->() = {
        //[unowned self] in
        print("The name is \(self.name)")
    }
    init(name: String) {
        self.name = name
    }
    deinit {
        print("Person deinit \(self.name)")
    }
}


class ViewController: UIViewController {

    //private var mmView: MemoryLeakView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        mmLeakDemo()
        
        //Demo()
    }
    
    private func mmLeakDemo() {
        
        let mmViewF = CGRect(x: 0,
                             y: 0,
                             width: view.bounds.width,
                             height: 300)
        
        let mmView = MemoryLeakView(frame: mmViewF)
        //mmView = MemoryLeakView(frame: mmViewF)
        mmView.backgroundColor = UIColor.grayColor()
        view.addSubview(mmView)
        
        // [unowned mmView] in
        // [unowned self] in
        mmView.buttonAction = {[weak mmView] in
            // [unowned self] in
            mmView?.removeFromSuperview()
            //mmView = nil
        }
    }
    
    private func Demo() {
        
        var a: Person? = Person(name: "a")
        a?.printName()
        a = nil
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

