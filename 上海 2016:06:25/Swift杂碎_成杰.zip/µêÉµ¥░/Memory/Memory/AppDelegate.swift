//
//  AppDelegate.swift
//  Memory
//
//  Created by 成杰 on 16/6/22.
//  Copyright © 2016年 swiftc.org. All rights reserved.
//

import UIKit

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?


    func application(application: UIApplication, didFinishLaunchingWithOptions launchOptions: [NSObject: AnyObject]?) -> Bool {
        
        
        return true
    }
    
    

}

