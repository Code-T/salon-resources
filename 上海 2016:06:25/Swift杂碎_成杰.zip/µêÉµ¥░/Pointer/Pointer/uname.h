//
//  uname.h
//  Pointer
//
//  Created by chengjie on 16/6/19.
//  Copyright © 2016年 A. All rights reserved.
//

#ifndef uname_h
#define uname_h

#include <stdio.h>

void get_uname();
void c_func(void (callback)(int, int));

#endif /* uname_h */
