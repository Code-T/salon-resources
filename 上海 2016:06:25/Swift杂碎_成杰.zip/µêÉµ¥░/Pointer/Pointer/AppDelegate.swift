//
//  AppDelegate.swift
//  Pointer
//
//  Created by chengjie on 16/6/19.
//  Copyright © 2016年 A. All rights reserved.
//

import UIKit
import SystemConfiguration.CaptiveNetwork
import NetworkExtension.NEHotspotHelper

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?
    
    let reachability = Reachability.shared

    func application(application: UIApplication, didFinishLaunchingWithOptions launchOptions: [NSObject: AnyObject]?) -> Bool {
        
        //unameDemo()
        
        //reachabilityDemo()
        
        //cCallbackDemo()
        
        //getWifiInfoDemo()
        
        addrAndPtrDemo()
        
        return true
    }
    
    // demo of withUnsafePointer and unsafeBitCast
    private func unameDemo() {
        
        // C的用法
        //get_uname()
        
        var name = utsname()
        print("machine:\(name.machine)")
        
        uname(&name)
        print("machine:\(name.machine)")
        
        let machine = withUnsafePointer(&name.machine) { (ptr) -> String in
            
            let int8Ptr = unsafeBitCast(ptr, UnsafePointer<CChar>.self)
            
            //let size = sizeofValue(name.machine)
            //sizeof(name.machine.dynamicType)
            //printHexOfPointer(int8Ptr, length: size)
            
            let str = String.fromCString(int8Ptr)
            
            if str == nil {
                return ""
            } else {
                return str!
            }
        }
        
        print("machine:\(machine)")
    }
    
    private func reachabilityDemo() {
        NSNotificationCenter.defaultCenter().addObserver(self,
                                                         selector: #selector(networkChanged),
                                                         name: Reachability.networkChangedNotiName,
                                                         object: reachability)
    }
    
    @objc func networkChanged(noti: NSNotification) {
        
        guard let reach = noti.object as? Reachability else {
            print("noti.object convert error")
            return
        }
        print(reach.isReachable())
        print(reach.isViaWiFi())
        print(reach.isViaCellular())
    }
    
    private func cCallbackDemo() {
        
        // callback真正实现的地方
        c_func { (a: Int32, b: Int32) in
            
            print("a:\(a)")
            print("b:\(b)")
        }
        
        // @convention(swift, block, c)
        // 属性标记，表示函数应该使用C调用约定, 意思就是告诉编译器这是C的调用惯例 && 不捕获闭包外的上下文（context）
        // 不捕获值的闭包都可以作为一个C函数指针直接传递
        //let cf = CFunctionPointer<Int>() //swift 1.x中的，现在已经废弃了
        //let cCallBack: (Int32, Int32) -> Void = {
        let cCallBack: @convention(c) (Int32, Int32) -> Void = {
            (a: Int32, b: Int32) -> Void in
            
            print("a:\(a)")
            print("b:\(b)")
        }
        
        //cCallBack(11, 21)
        
        c_func(cCallBack)
        
    }
    
    // CFDictionary转 Dictionary<String, AnyObject>
    private func getWifiInfoDemo() {
        
        if !isRunningOniOSDevice() {
            fatalError("模拟器没有无线网卡，调用CNCopySupportedInterfaces()将会返回nil")
        }
        
        let interfaces = CNCopySupportedInterfaces()
        let en0 = CFArrayGetValueAtIndex(interfaces, 0)
        let ifName = unsafeBitCast(en0, CFString.self)
        
        let cfDic = CNCopyCurrentNetworkInfo(ifName)
        guard cfDic != nil else {
            return
        }
        let nsDic = cfDic! as NSDictionary
        
        guard let dic = nsDic as? Dictionary<String, AnyObject> else {
            return
        }
        print(dic)
        
    }
    
    private func addrAndPtrDemo() {
        var a = [1, 2, 3]
        let ptr = withUnsafePointer(&a) { (ptr) -> UnsafePointer<[Int]> in
            return ptr
        }
        print("a's ptr:\(ptr)")
        
        print("memory of ptr:\(ptr.memory)")
        
        let addr = unsafeAddressOf(a)
        
        print("a's addr:\(addr)")
        
        printHexOfPointer(&a, length: a.count * sizeof(Int))
        
        addr_of(a)
        
    }

}

