//
//  addr.h
//  Pointer
//
//  Created by lijunge on 16/6/24.
//  Copyright © 2016年 A. All rights reserved.
//

#ifndef addr_h
#define addr_h

#include <stdio.h>

void addr_of(const void * const a);

#endif /* addr_h */
