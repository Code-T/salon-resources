//
//  uname.c
//  Pointer
//
//  Created by chengjie on 16/6/19.
//  Copyright © 2016年 A. All rights reserved.
//

#include "uname.h"
#include <sys/utsname.h>

#include <SystemConfiguration/CaptiveNetwork.h>

void get_uname() {
    
    struct utsname name;
    
    uname(&name);
    
    printf("sysname:%s\n", name.sysname);
    printf("nodename:%s\n", name.nodename);
    printf("release:%s\n", name.release);
    printf("version:%s\n", name.version);
    printf("machine:%s\n", name.machine);
    
}

// callback真正调用的地方
void c_func(void (callback)(int, int)) {
    callback(1, 2);
}

void get_wifi_name() {
    
//    CFArrayRef interfaces = CNCopySupportedInterfaces();
//    CFIndex count = CFArrayGetCount(interfaces);
//    
//    for (int i = 0; i < count; ++i) {
//        printf("uu\n");
//    }
}