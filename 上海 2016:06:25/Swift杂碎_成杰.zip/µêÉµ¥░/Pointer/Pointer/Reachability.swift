//
//  Reachability.swift
//  Pointer
//
//  Created by chengjie on 16/6/20.
//  Copyright © 2016年 A. All rights reserved.
//

import UIKit
import SystemConfiguration.SCNetworkReachability

// c callback
// Unmanaged && COpaquePointer

final class Reachability {

    // MARK: - Out interface
    static let networkChangedNotiName = "networkChangedNotification"
    
    func isReachable() -> Bool {
        let flags = reachabilityFlags
        return isReachableWithFlags(flags)
    }
    
    func isViaCellular() -> Bool {
        
        let flags = reachabilityFlags
        
        // Check we're not on the simulator, we're REACHABLE and check we're on WWAN
        return isRunningOniOSDevice() && isReachable() && isOnWWAN(flags)
    }
    
    func isViaWiFi() -> Bool {
        
        let flags = reachabilityFlags
        
        // Check we're reachable
        if !isReachable() {
            return false
        }
        
        // Must be on WiFi if reachable but not on an iOS device (i.e. simulator)
        if !isRunningOniOSDevice() {
            return true
        }
        
        // Check we're NOT on WWAN
        return !isOnWWAN(flags)
    }
    
    class var shared: Reachability {
        
        dispatch_once(&Inner.token, {
            // 注册网络状态变化的通知
            do {
                try Inner.instance = Reachability(hostName: "www.baidu.com")
                do {
                    try Inner.instance!.startMonitorChange()
                } catch {
                    print("reachablity startMonitorChange error:\(error)")
                }
            } catch {
                print("reachablity init error:\(error)")
            }
        })
        return Inner.instance!
    }
    
    // MARK: - Inner interface
    private struct Inner {
        static var instance: Reachability?
        static var token: dispatch_once_t = 0
    }

    private convenience init(hostName: String) throws {
        
        self.init()
        
        let nodeName = (hostName as NSString).UTF8String
        
        guard let networkReach = SCNetworkReachabilityCreateWithName(kCFAllocatorDefault, nodeName) else {
            throw ReachabilityError.Create
        }
        
        self.reachability = networkReach
    }
    
    private func startMonitorChange() throws {
        
        var context = SCNetworkReachabilityContext(version: 0,
                                                   info: nil,
                                                   retain: nil,
                                                   release: nil,
                                                   copyDescription: nil)
        
        context.info = UnsafeMutablePointer(Unmanaged.passUnretained(self).toOpaque())
        guard reachability != nil else { return }
        
        // callback
        // reachabilityCallback
        if !SCNetworkReachabilitySetCallback(reachability!, callback, &context) {
            stopMonitorChange()
            throw ReachabilityError.SetCallback
        }
        
        if !SCNetworkReachabilitySetDispatchQueue(reachability!, reachabilitySerialQueue) {
            stopMonitorChange()
            throw ReachabilityError.SetDispatchQueue
        }
        
        dispatch_async(reachabilitySerialQueue) { () -> Void in
            let flags = self.reachabilityFlags
            self.reachabilityChanged(flags)
        }
    }
    
    private var callback: SCNetworkReachabilityCallBack = { (
        target: SCNetworkReachability,
        flags: SCNetworkReachabilityFlags,
        info: UnsafeMutablePointer<Void>) -> Void in
    
        //  因为info的类型没有字面显示出来
        let opaquePtr = COpaquePointer(info)
        let unmanagedReach = Unmanaged<Reachability>.fromOpaque(opaquePtr)
        let reach = unmanagedReach.takeUnretainedValue()
        
        //let reach = unsafeBitCast(info, Reachability.self)
        
        dispatch_async(dispatch_get_main_queue()) {
            reach.reachabilityChanged(flags)
        }
    }
    
    private func stopMonitorChange() {
        
        guard self.reachability != nil else {
            return
        }
        SCNetworkReachabilitySetCallback(reachability!, nil, nil)
        SCNetworkReachabilitySetDispatchQueue(reachability!, nil)
    }
    
    private func isOnWWAN(flags: SCNetworkReachabilityFlags) -> Bool {
        #if os(iOS)
            return flags.contains(.IsWWAN)
        #else
            return false
        #endif
    }
    
    private func reachabilityChanged(flags: SCNetworkReachabilityFlags) {
        
        guard previousFlags != flags else { return }
        notificationCenter.postNotificationName(Reachability.networkChangedNotiName, object:self)
        previousFlags = flags
    }
    
    private var reachabilityFlags: SCNetworkReachabilityFlags {
        
        guard let reachability = reachability else {
            return SCNetworkReachabilityFlags()
        }
        
        var flags = SCNetworkReachabilityFlags()
        let gotFlags = withUnsafeMutablePointer(&flags) {
            SCNetworkReachabilityGetFlags(reachability, UnsafeMutablePointer($0))
        }
        
        if gotFlags {
            return flags
        } else {
            return SCNetworkReachabilityFlags()
        }
    }
    
    private func isReachableWithFlags(flags: SCNetworkReachabilityFlags) -> Bool {
        
        if !flags.contains(.Reachable) {
            return false
        }
        
        if isConnectionRequiredOrTransient(flags) {
            return false
        }
        
        if !isRunningOniOSDevice() {
            return false
        }
        
        return true
    }
    
    private func isConnectionRequiredOrTransient(flags: SCNetworkReachabilityFlags) -> Bool {
        let testCase: SCNetworkReachabilityFlags = [.ConnectionRequired, .TransientConnection]
        return flags.intersect(testCase) == testCase
    }
    
    private var reachability: SCNetworkReachability?
    private var previousFlags: SCNetworkReachabilityFlags?
    private let notificationCenter = NSNotificationCenter.defaultCenter()
    private let reachabilitySerialQueue = dispatch_queue_create("org.swiftc.reachability", DISPATCH_QUEUE_SERIAL)
    
    deinit {
        stopMonitorChange()
        reachability = nil
        previousFlags = nil
    }
    
}

private func reachabilityCallback(reachability: SCNetworkReachability,
                                  flags: SCNetworkReachabilityFlags,
                                  info: UnsafeMutablePointer<Void>) {
    
    //  因为info的类型没有字面显示出来
    let opaquePtr = COpaquePointer(info)
    let unmanagedReach = Unmanaged<Reachability>.fromOpaque(opaquePtr)
    let reach = unmanagedReach.takeUnretainedValue()
    
    //let reach = unsafeBitCast(info, Reachability.self)
    
    dispatch_async(dispatch_get_main_queue()) {
        reach.reachabilityChanged(flags)
    }
}

enum ReachabilityError: ErrorType {
    case Create
    case SetCallback
    case SetDispatchQueue
}
