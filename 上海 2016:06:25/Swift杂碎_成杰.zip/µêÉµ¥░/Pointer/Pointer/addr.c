//
//  addr.c
//  Pointer
//
//  Created by lijunge on 16/6/24.
//  Copyright © 2016年 A. All rights reserved.
//

#include "addr.h"

void addr_of(const void * const a) {
    
    const char * b = a;
    printf("addr_of:%p\n", a);
    
    for (int i = 0; i < 3; ++i) {
        printf("##%x", b[i]);
    }
}