//
//  cstring.c
//  CString
//
//  Created by 成杰 on 16/6/21.
//  Copyright © 2016年 swiftc.org. All rights reserved.
//

#include "cstring.h"
#include <string.h>

void c_str(const void * const c) {
    
//    printf("c len: %lu\n", strlen(c));
//    printf("size of len: %lu", sizeof(c));
//    printf("c: %s\n", c);
    
    const char * s = c;
    
    for (int i = 0; i < strlen(c); ++i) {
        printf("*%c\n", s[i]);
    }
}