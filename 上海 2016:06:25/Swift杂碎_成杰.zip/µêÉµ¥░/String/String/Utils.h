//
//  Utils.h
//
//  Created by 成杰 on 16/6/17.
//

#ifndef Utils_h
#define Utils_h

#include <stdio.h>

void printHex(const void * const ptr, const unsigned len);

#endif /* Utils_h */
