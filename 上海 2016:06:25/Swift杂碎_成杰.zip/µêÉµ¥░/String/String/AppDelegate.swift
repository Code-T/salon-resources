//
//  AppDelegate.swift
//  CString
//
//  Created by 成杰 on 16/6/21.
//  Copyright © 2016年 swiftc.org. All rights reserved.
//

import UIKit

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {
    
    var window: UIWindow?
    
    func application(application: UIApplication, didFinishLaunchingWithOptions launchOptions: [NSObject: AnyObject]?) -> Bool {
        
        //cStringDemo()
        
        subStrDemo()
        
        return true
    }
    
    private func cStringDemo() {
        
        let str = "abc"
        
        let cStrPtr = str.withCString { (ptr) -> UnsafePointer<CChar> in
            return ptr
        }
        
        let s = String.fromCString(cStrPtr)
        print("s:\(s)")
        
        
        //c_str(cStrPtr)
        printHex(cStrPtr, UInt32(str.characters.count+1))
        
        printHexOfPointer(cStrPtr, length: str.characters.count+1)
        
        let cbuf = str.cString
        print("cbuf:\(cbuf)")
        
        let asciiStr = String.fromCString(str.asciiString)
        print("asciiStr:\(asciiStr)")
        
        let asciiStrII = String.fromCString(str.asciiStringII)
        print("asciiStrII:\(asciiStrII)")
        
        c_str(str.asciiStringII)
    }
    
    private func subStrDemo() {
        
        let str = "012🍎❤️画……％"
        
        let s1 = (str as NSString).substringFromIndex(3)
        
        print(s1)
        
        let index = str.startIndex.advancedBy(4)
        
        //print(index.dynamicType)
        
        //let idx = String.Index
        
        let s2 = str.substringFromIndex(index)
        
        print(s2)
        
        let tart = str.startIndex
        
        let end = str.endIndex.advancedBy(-1)
        
        let s3 = str.substringWithRange(tart..<end)
        
        print(s3)
    }
    
}

