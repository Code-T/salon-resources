//
//  cstring.h
//  CString
//
//  Created by 成杰 on 16/6/21.
//  Copyright © 2016年 swiftc.org. All rights reserved.
//

#ifndef cstring_h
#define cstring_h

#include <stdio.h>

void c_str(const void * const c);

#endif /* cstring_h */
