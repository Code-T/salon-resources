//
//  AppDelegate.swift
//  Prebuild
//
//  Created by 成杰 on 16/6/23.
//  Copyright © 2016年 swiftc.org. All rights reserved.
//

import UIKit

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?


    func application(application: UIApplication, didFinishLaunchingWithOptions launchOptions: [NSObject: AnyObject]?) -> Bool {
        
        //ifDemo()
        
        //osArchDemo()
        
        //avaiableDemo()
        
        Log("lala")
        return true
    }

    private func ifDemo() {
        
        #if DEBUG
            print("debug")
        #endif
        
        #if RELASE
            print("relase")
        #endif
        
        // build settings ->Swift Compiler - Custom Flags -> Other Swift Flags
        #if Debug
            print("debug")
        #else
            print("release")
        #endif
        
        #if Release
            print("release")
        #endif
    }

    private func osArchDemo() {
        
        if !isRunningOniOSDevice() {
            print("not iOS device")
        }
    }
    
    private func avaiableDemo() {
        
        ScreenshotManager.detectScreenshot { (image: UIImage) -> Void in
            
            print("image1:\(image)")
        }
    }
    
    private var bgTask = UIBackgroundTaskInvalid
    
    func applicationDidEnterBackground(application: UIApplication) {
        
        guard UIDevice.currentDevice().multitaskingSupported else {
            return
        }
        
        bgTask = application.beginBackgroundTaskWithExpirationHandler(nil)
        
        ScreenshotManager.detectScreenshot { (image: UIImage) -> Void in
            
            print("image2:\(image)")
        }
    }

}

