//
//  ScreenshotManager.swift
//  ImagePicker
//
//  Created by 成杰 on 15/11/17.
//  Copyright © 2015年 成杰. All rights reserved.
//

import UIKit
import Photos
import Foundation
import AssetsLibrary

//@available(iOS 8.0, *)
//class SManager: NSObject, PHPhotoLibraryChangeObserver {
//    
//    static var shared: SManager {
//        dispatch_once(&Inner.token) {
//            Inner.instance = SManager()
//            
//        }
//        return Inner.instance!
//    }
//    
//    private struct Inner {
//        static var instance: SManager?
//        static var token: dispatch_once_t = 0
//    }
//    
////    if #available(iOS 8.0, *) {
////    
////    }
//    
//    var completion: ((UIImage) -> Void)!
//    
//    @available(iOS 8.0, *)
//    private var allPhotosFetchResult: PHFetchResult?
//    
//    private var allPhotosFetchResult: PHFetchResult = {
//        
//        print("****")
//        let photosOptions = PHFetchOptions()
//        photosOptions.sortDescriptors = [NSSortDescriptor(key: "creationDate", ascending: false)]
//        let photosFetchResult = PHAsset.fetchAssetsWithMediaType(.Image, options: photosOptions)
//        PHPhotoLibrary.sharedPhotoLibrary().registerChangeObserver(SManager.shared)
//        return photosFetchResult
//    }()
//    
//    // MARK: - PHPhotoLibraryChangeObserver
//    @available(iOS 8.0, *)
//    func photoLibraryDidChange(changeInstance: PHChange) {
//        
//        let changeDetail = changeInstance.changeDetailsForFetchResult(allPhotosFetchResult)
//        
//        guard changeDetail != nil else {
//            return
//        }
//        
//        guard changeDetail?.insertedIndexes != nil else {
//            return
//        }
//        // ...
//    }
//}


// 对外统一使用这个接口
class ScreenshotManager: NSObject {
    
    private static var shared: ScreenshotManager {
        dispatch_once(&Inner.token) {
            Inner.instance = ScreenshotManager()
        }
        return Inner.instance!
    }
    
    private struct Inner {
        static var instance: ScreenshotManager?
        static var token: dispatch_once_t = 0
    }
    
    class func detectScreenshot(result: ((UIImage) -> Void)?) {
        
        if #available(iOS 8.0, *) {
            ScreenshotManagerEx.detectScreenshot({ (UIImage) -> Void in
                guard result != nil else { return }
                result!(UIImage)
            })
        } else { // iOS7
            ScreenshotManagerLo.detectScreenshot({ (UIImage) -> Void in
                guard result != nil else { return }
                result!(UIImage)
            })
        }
    }
    
    class func scanScreenshots(result: ([UIImage]) -> Void) {
        
        if #available(iOS 8.0, *) {
            ScreenshotManagerEx.scanScreenshots({ (UIImages) -> Void in
                result(UIImages)
            })
        } else {
            ScreenshotManagerLo.scanScreenshots({ (UIImages) -> Void in
                result(UIImages)
            })
        }
    }
    
    class func clearScreenshots() {
        if #available(iOS 8.0, *) {
            ScreenshotManagerEx.clearScreenshots()
        } else {
            // iOS7 不停供清理截图的功能，是因为iOS7不能删除非该App生成的图片
            // 而且调用该接口的代码得保证iOS7不会跑到该处
        }
    }
    
    class func stopDetectingScreenshots() {
        if #available(iOS 8.0, *) {
            // dooooooooooö
        } else { // iOS 7
            ScreenshotManagerLo.stopDetectingScreenshots()
        }
    }
}

// 该类供iOS7用，iOS8以及以上版本使用ScreenshotManagerEx
private class ScreenshotManagerLo: NSObject {
    
    private var completion: ((UIImage) -> Void)?
    private var groupCountDic = [String: Int]()
    private var timer: NSTimer?
    
    private static var shared: ScreenshotManagerLo {
        dispatch_once(&Inner.token) { () -> Void in
            Inner.instance = ScreenshotManagerLo()
        }
        return Inner.instance!
    }
    
    private struct Inner {
        static var instance: ScreenshotManagerLo?
        static var token: dispatch_once_t = 0
    }
    
    private func startTimer() {
        timer = NSTimer.scheduledTimerWithTimeInterval(1.0, target: self,
            selector: #selector(checkingNewScreenshot), userInfo: nil, repeats: true)
    }
    
    private func stopTimer() {
        if timer != nil {
            timer!.invalidate()
            timer = nil
        }
    }

    class func detectScreenshot(completion: ((UIImage) -> Void)?) {
        
        self.shared.completion = completion
        self.shared.startTimer()
    }
    
    dynamic func checkingNewScreenshot() { // 为了隐藏ScreenshotManagerLo类，不让用户直接使用
        
        print("checking new screenshot...")
        let library = ALAssetsLibrary()
        library.enumerateGroupsWithTypes(ALAssetsGroupSavedPhotos, usingBlock: { (group, stop) -> Void in
            guard group != nil else { return }
            guard let groupName = group.valueForProperty(ALAssetsGroupPropertyPersistentID) as? String else {
                return
            }
            group.setAssetsFilter(ALAssetsFilter.allPhotos())
            if self.groupCountDic[groupName] == nil {
                self.groupCountDic[groupName] = group.numberOfAssets()
            }
            if group.numberOfAssets() > self.groupCountDic[groupName]! {
                group.enumerateAssetsAtIndexes(NSIndexSet(index: group.numberOfAssets()-1), options: .Concurrent,
                    usingBlock: { (alAsset, index, innerStop) -> Void in
                    if alAsset != nil {
                        let representation = alAsset.defaultRepresentation()
                        let latestPhoto = UIImage(CGImage: representation.fullScreenImage().takeUnretainedValue())
                        if latestPhoto.isScreenshot() {
                            dispatch_async(dispatch_get_main_queue(), { () -> Void in
                                if self.completion != nil {
                                    // 出口
                                    self.completion!(latestPhoto)
                                }
                            })
                        }
                        self.groupCountDic[groupName] = group.numberOfAssets()
                    }
                })
            }
            }) { (error) -> Void in
                print("checking new screenshot error:\(error)")
        }
    }
    
    class func scanScreenshots(result: ([UIImage]) -> Void) {
        
        var images = [UIImage]()
        let library = ALAssetsLibrary()
        
        library.enumerateGroupsWithTypes(ALAssetsGroupSavedPhotos, usingBlock: { (group, nil) -> Void in
            
            guard group != nil else { return }
            
            group.enumerateAssetsUsingBlock({ (alAsset, index, stop) in
                
                guard alAsset != nil else { return }
                
                guard let type = alAsset.valueForProperty(ALAssetPropertyType),
                    let date = alAsset.valueForProperty(ALAssetPropertyDate) else { return }
                
                guard let t = type as? String, let d = date as? NSDate else { return }
                
                let twoDayBefore = NSDate(timeInterval: -2*24*60*60, sinceDate: NSDate())
                
                if t == ALAssetTypePhoto && d.compare(twoDayBefore) == .OrderedDescending {
                    
                    let url = alAsset.defaultRepresentation().url()
                    library.assetForURL(url,
                        resultBlock: { (asset) in
                            
                            let cgImg = asset.defaultRepresentation().fullScreenImage().takeUnretainedValue()
                            let img = UIImage(CGImage: cgImg)
                            if img.isScreenshot() {
                                images.append(img)
                            }
                            
                            if index == group.numberOfAssets() - 1 {
                                stop.memory = ObjCBool(true)
                                result(images)
                            }
                            
                        },
                        failureBlock: { (error) in
                            print("library.assetForURL error: \(error)")
                    })
                    
                }
                
            })
            
        }) { (error) -> Void in
            print("\(#function) error:\(error)")
        }
        
    }
    
    class func stopDetectingScreenshots() {
        self.shared.stopTimer()
        self.shared.completion = nil
        self.shared.timer = nil
    }
    
    deinit {
        completion = nil
        stopTimer()
        //groupCountDic = [:]
    }
}

// 给iOS8+用的
@available(iOS 8.0, *)
private class ScreenshotManagerEx: NSObject, PHPhotoLibraryChangeObserver {
    
    private var allPhotosFetchResult: PHFetchResult?
    private var completion: ((UIImage) -> Void)?
    private var assets = [PHAsset]()
    
    private static var shared: ScreenshotManagerEx {
        dispatch_once(&Inner.token) { () -> Void in
            Inner.instance = ScreenshotManagerEx()
        }
        return Inner.instance!
    }
    
    private struct Inner {
        static var instance: ScreenshotManagerEx?
        static var token: dispatch_once_t = 0
    }
    
    class func scanScreenshots(result: ([UIImage]) -> Void) {
        
        var images = [UIImage]()
        
        let photosOptions = PHFetchOptions()
        photosOptions.sortDescriptors = [NSSortDescriptor(key: "creationDate", ascending: false)]
        let photoFetchResult = PHAsset.fetchAssetsWithMediaType(PHAssetMediaType.Image,
            options: photosOptions)
        
        let imgCount = photoFetchResult.countOfAssetsWithMediaType(.Image)
        var imgNum = 20
        if imgNum > imgCount { // 防止超出
            imgNum = imgCount
        }
        
        let requestOption = PHImageRequestOptions()
        requestOption.deliveryMode = .HighQualityFormat
        requestOption.networkAccessAllowed = false
        requestOption.synchronous = true
        requestOption.resizeMode = .Exact
        
        for i in 0..<imgNum {
            
            if let ass = photoFetchResult[i] as? PHAsset {
                if ass.mediaType == .Image &&
                    ass.isScreenshot &&
                    ass.representsBurst == false {
                    
                    PHImageManager.defaultManager().requestImageForAsset(ass,
                        targetSize: UIScreen().pixelSize,
                        contentMode: .Default,
                        options: requestOption,
                        resultHandler: { (result, info) -> Void in
                            
                            guard result != nil else { return }
                            
                            images.append(result!)
                            self.shared.assets.append(ass)
                    })
                }
            }
        }
        
        result(images.reverse())
    }
    
    class func detectScreenshot(completion: ((UIImage) -> Void)?) {
        self.shared.completion = completion
        self.shared.initFetResult()
    }
    
    private func initFetResult() {
        
        let allPhotosOptions = PHFetchOptions()
        allPhotosOptions.sortDescriptors = [NSSortDescriptor(key: "creationDate", ascending: false)]
        allPhotosFetchResult = PHAsset.fetchAssetsWithMediaType(.Image, options: allPhotosOptions)
        PHPhotoLibrary.sharedPhotoLibrary().registerChangeObserver(self)
    }
    
    class func clearScreenshots() {
        
        PHPhotoLibrary.sharedPhotoLibrary().performChanges({ () -> Void in
            PHAssetChangeRequest.deleteAssets(self.shared.assets)
            }, completionHandler: { (success, error) -> Void in
                
                if error == nil && success == true {
                    print("清理图片成功")
                } else {
                    print("清理图片失败:\(error)")
                }
        })
    }
    
    deinit {
        PHPhotoLibrary.sharedPhotoLibrary().unregisterChangeObserver(self)
        self.completion = nil
    }
    
    // MARK: - PHPhotoLibraryChangeObserver
    dynamic func photoLibraryDidChange(changeInstance: PHChange) {
        
        let changeDetail = changeInstance.changeDetailsForFetchResult(allPhotosFetchResult!)
        
        guard changeDetail != nil else {
            return
        }
        
        guard changeDetail?.insertedIndexes != nil else {
            return
        }
        
        dispatch_async(dispatch_get_main_queue()) { [unowned self] in
            
            self.allPhotosFetchResult = changeDetail!.fetchResultAfterChanges
            
            guard changeDetail!.hasIncrementalChanges else { return }
            
            guard let ass = self.allPhotosFetchResult!.firstObject as? PHAsset else { return }
            
            guard ass.isScreenshot else { return }
            
            let requestOption = PHImageRequestOptions()
            requestOption.deliveryMode = .HighQualityFormat
            requestOption.networkAccessAllowed = false
            requestOption.synchronous = true
            requestOption.resizeMode = .Exact
            
            let scrPsize = UIScreen().pixelSize
            
            let phImageMngr = PHImageManager.defaultManager()
            phImageMngr.requestImageForAsset(ass,
                                             targetSize: scrPsize,
                                             contentMode: .Default,
                                             options: requestOption,
                                             resultHandler: { [unowned self] (image, info) in
                                                
                                                guard self.completion != nil && image != nil else {
                                                    return
                                                }
                                                
                                                self.completion!(image!)
                                                
                })
        }
    }
}

extension UIImage {
    
    func isScreenshot() -> Bool {
        let mainScreen = UIScreen.mainScreen()
        let scale = mainScreen.scale
        let imageWidth = self.size.width
        let imageHeight = self.size.height
        let screenWidth = mainScreen.bounds.size.width * scale
        let screenHeight = mainScreen.bounds.size.height * scale
        // 没考虑横屏的情况
        return imageWidth == screenWidth && imageHeight == screenHeight
    }
}

extension UIScreen {
    
    var pixelHeight: CGFloat {
        let hight = UIScreen.mainScreen().bounds.height
        let scale = UIScreen.mainScreen().scale
        return hight * scale
    }
    
    var pixelWidth: CGFloat {
        let width = UIScreen.mainScreen().bounds.width
        let scale = UIScreen.mainScreen().scale
        return width * scale
    }
    
    var pixelSize: CGSize {
        return CGSize(width: pixelWidth, height: pixelHeight)
    }
}

@available(iOS 8.0, *)
extension PHAsset {
    
    var isScreenshot: Bool {
        let isHeightEqual = Int(UIScreen().pixelHeight) == pixelHeight
        let isWidthEqual = Int(UIScreen().pixelWidth) == pixelWidth
        return isHeightEqual && isWidthEqual
    }
}
