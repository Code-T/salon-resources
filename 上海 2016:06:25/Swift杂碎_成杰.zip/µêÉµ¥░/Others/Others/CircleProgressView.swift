//
//  CircleProgressView.swift
//  CircleAnimationDemo
//
//  Created by 成杰 on 16/4/11.
//  Copyright © 2016年 swiftc.org. All rights reserved.
//

import UIKit

class CircleProgressView: UIView {

    var trackColor = UIColor.lightGrayColor()   // 底色
    var progressColor = UIColor.blueColor()     // 进度条的颜色
    
    var progressWidth: CGFloat = 0 {
        didSet {
            configureTrack()
            configureProgress()
        }
    }
    
    var progress: Float = 0 {
        didSet {
            progress = progress < 0 ? 0 : progress
            progress = progress > 1 ? 1 : progress
            configureProgress()
        }
    }
    
    convenience init(origin: CGPoint, radius: CGFloat) {
        
        let frame = CGRect(origin: origin,
                           size: CGSize(width: radius, height: radius))
        self.init(frame: frame)
        
        progressWidth = CGFloat(radius*(1/10.0))
        
        configureTrack()
        layer.addSublayer(trackLayer)
        
        configureProgress()
        layer.addSublayer(progressLayer)
    }
    
    private var timer: NSTimer!
    
    func autoRun(inSecond second: Double) {
        let count: Double = 1 / Double(step)
        timer = NSTimer.scheduledTimerWithTimeInterval(second/count, target: self,
                                               selector: #selector(updateProgress),
                                               userInfo: nil,
                                               repeats: true)
    }
    
    private let step = Float(0.01)
    
    dynamic private func updateProgress() {
        progress += step
        if progress == 1 {
            if timer == nil {
                timer.invalidate()
                timer = nil
            }
        }
    }
    
    private func configureTrack() {
        let radius = (bounds.width - progressWidth) / 2
        let trackPath = UIBezierPath(arcCenter: center,
                                     radius: radius,
                                     startAngle: 0,
                                     endAngle: CGFloat(M_PI * 2),
                                     clockwise: true)
        trackLayer.frame = bounds
        trackLayer.path = trackPath.CGPath
        trackLayer.lineWidth = progressWidth
        trackLayer.strokeColor = trackColor.CGColor
        trackLayer.fillColor = UIColor.clearColor().CGColor
    }
    
    private func configureProgress() {
        let radius = (bounds.width - progressWidth) / 2
        let progressPath = UIBezierPath(arcCenter: center,
                                        radius: radius,
                                        startAngle: -CGFloat(M_PI_2),
                                        endAngle: CGFloat(Float(M_PI*2)*progress - Float(M_PI_2)),
                                        clockwise: true)
        progressLayer.frame = bounds
        progressLayer.lineWidth = progressWidth
        progressLayer.lineCap = kCALineCapRound
        progressLayer.path = progressPath.CGPath
        progressLayer.strokeColor = progressColor.CGColor
        progressLayer.fillColor = UIColor.clearColor().CGColor
    }
    
    private let trackLayer = CAShapeLayer()
    private let progressLayer = CAShapeLayer()
    
    deinit {
        timer.invalidate()
        timer = nil
    }
    
    private override init(frame: CGRect) {
        super.init(frame: frame)
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
}
