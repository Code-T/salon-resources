//
//  ViewController.swift
//  Others
//
//  Created by 成杰 on 16/6/23.
//  Copyright © 2016年 swiftc.org. All rights reserved.
//

import UIKit

class ViewController: UIViewController, AudioEncoderDelegate {
    
    private var cpv: CircleProgressView!
    
    private let vCapture = VideoCapture()
    private let aCapture = AudioCapture()
    
    private let vEncoder = VideoEncoder()
    private let aEncoder = AudioEncoder()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //circleProgressDemo()
        
        //privateDemo()
        
        //captureDemo()
        
        let d = NSCalendar(calendarIdentifier: <#T##String#>)
    }
    
    // didSet
    private func circleProgressDemo() {
        cpv = CircleProgressView(origin: CGPoint(x: 100, y: 100),
                                 radius: 100)
        view.addSubview(cpv)
        
        // way first
//        NSTimer.scheduledTimerWithTimeInterval(0.1,
//                                               target: self,
//                                               selector: #selector(updateProgress),
//                                               userInfo: nil,
//                                               repeats: true)
        
        // or another way
        cpv.autoRun(inSecond: 2.0)
    }

    dynamic func updateProgress() {
        cpv.progress += 0.1
    }
    
    private func privateDemo() {
        
        let dv = DemoView(frame: view.bounds)
        dv.test()
    }
    
    private func captureDemo() {
        
        // protocol 和 extension 搭配
        // 巧用闭包和计算属性， lazy var保证代码只执行一次， AudioConverterRef（没有init的结构体，仅供特定C函数的参数来生成)
        aCapture.startSession()
        aEncoder.delegate = self
        aCapture.output { [unowned self] (sampleBuffer) in
            
            self.aEncoder.encode(sampleBuffer: sampleBuffer)
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - AudioEncoderDelegate
    func onAudioEncoderGet(audio: NSData) {
        print("audio data length: \(audio.length)")
    }
}

class DemoView: UIView {
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        commonInit()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        commonInit()
    }
    
    private func commonInit() {
        self.backgroundColor = UIColor.blackColor()
    }
    
    private func test() {
        print("不应该能访问我的啊")
    }
}



