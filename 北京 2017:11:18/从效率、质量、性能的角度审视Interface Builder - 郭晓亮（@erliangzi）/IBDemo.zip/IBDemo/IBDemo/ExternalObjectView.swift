/*!
 @summary  ExternalObjectView
 @detail   External Object演示类
 @author   @erliangzi
 */

import UIKit

class ExternalObjectView: UIView {

    @IBAction func handleInView(_ sender: Any) {
        print("handle in view")
    }
}
