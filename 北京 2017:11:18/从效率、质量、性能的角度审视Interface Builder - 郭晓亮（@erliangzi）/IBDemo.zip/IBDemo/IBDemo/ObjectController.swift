/*!
 @summary  ObjectController
 @detail   Object演示类
 @author   @erliangzi
 */

import UIKit

class ObjectController: UIViewController {
    @IBOutlet var helper: ObjectHelper!
    
    @IBAction func handleTestInVC(_ sender: Any) {
        print("handle test in VC")
    }
}
