/*!
 @summary  ObjectController
 @detail   Object演示类
 @author   @erliangzi
 */

import UIKit

class ObjectHelper: NSObject, UITableViewDelegate, UITableViewDataSource {
    @IBInspectable var type: String? = "none"
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 20
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "test")
        cell?.textLabel?.text = "\(type!):\(indexPath.row)"
        return cell!
    }
    
    @IBAction func handleTestInHelper(_ sender: Any) {
        print("handle test in helper")
    }
}
