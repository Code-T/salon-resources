/*!
 @summary  ExternalObjectController
 @detail   External Object演示类
 @author   @erliangzi
 */

import UIKit

class ExternalObjectController: UIViewController {
    //不能在xib中拖，只能手动创建
    let helper = ExternalObjectHelper()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let paramDic = ["ExternalObjectHelper": helper]
        let optDic = [UINibExternalObjects: paramDic]
        let eoView = Bundle.main.loadNibNamed("ExternalObjectView", owner: self, options: optDic)![0] as! UIView
        eoView.center = view.center
        view.addSubview(eoView)
    }
    
    @IBAction func handleInVC(_ sender: Any) {
        print("handle in vc")
    }
}
