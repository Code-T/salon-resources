/*!
 @summary  UnWindSegueAController
 @detail   UnwindSegue演示类
 @author   @erliangzi
 */

import UIKit

class UnWindSegueAController: UIViewController {
    @IBOutlet var typeLabel: UILabel!
    
    @IBAction func selectTypeCallback(unWindSegue: UIStoryboardSegue) {
        if unWindSegue.identifier == "unwind" {
            let fromVC = unWindSegue.source as! UnWindSegueBController
            typeLabel.text = "type:" + fromVC.typeStr
        }
    }
    
    @IBAction func handleLongPress(_ sender: UILongPressGestureRecognizer) {
        if sender.state == .began {
            let alert = UIAlertController.init(title: "test long press", message: "long press began", preferredStyle: .alert)
            alert.addAction(UIAlertAction.init(title: "OK", style: .default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
    }
}
