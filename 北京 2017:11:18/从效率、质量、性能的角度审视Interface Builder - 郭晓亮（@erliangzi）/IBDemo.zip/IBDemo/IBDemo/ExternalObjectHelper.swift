/*!
 @summary  ExternalObjectHelper
 @detail   External Object演示类
 @author   @erliangzi
 */

import UIKit

class ExternalObjectHelper: NSObject {

    @IBAction func handleInHelper(_ sender: Any) {
        print("handle in helper")
    }
}
