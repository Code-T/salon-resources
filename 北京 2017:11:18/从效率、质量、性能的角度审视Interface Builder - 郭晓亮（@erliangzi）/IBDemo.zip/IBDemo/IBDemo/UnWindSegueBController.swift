/*!
 @summary  UnWindSegueBController
 @detail   UnwindSegue演示类
 @author   @erliangzi
 */

import UIKit

class UnWindSegueBController: UITableViewController {
    var typeStr = "none"
    var selectIndex = -1
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        if selectIndex != -1 {
            let cell = tableView.cellForRow(at: IndexPath.init(row: selectIndex, section: 0))
            cell?.accessoryType = .none
        }
        selectIndex = indexPath.row
        let cell = tableView.cellForRow(at: indexPath)
        cell?.accessoryType = .checkmark
        typeStr = (cell?.textLabel?.text) ?? "none"
    }
    
    @IBAction func selectComplete(_ sender: UIBarButtonItem) {
        navigationController?.popViewController(animated: true)
    }
}

